-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema sharehouse
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema sharehouse
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `sharehouse` DEFAULT CHARACTER SET utf8 ;
USE `sharehouse` ;

-- -----------------------------------------------------
-- Table `sharehouse`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`user` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(100) NOT NULL,
  `address` VARCHAR(500) NULL DEFAULT NULL,
  `gender` VARCHAR(1) NULL DEFAULT NULL,
  `birth` DATE NULL DEFAULT NULL,
  `area` VARCHAR(30) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`article`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`article` (
  `articleno` INT NOT NULL AUTO_INCREMENT,
  `userid` VARCHAR(16) NOT NULL,
  `subject` VARCHAR(100) NOT NULL,
  `content` VARCHAR(2000) NOT NULL,
  `regtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`articleno`),
  INDEX `happyhouse_username_FK_idx` (`userid` ASC) VISIBLE,
  CONSTRAINT `happyhouse_userid_FK`
    FOREIGN KEY (`userid`)
    REFERENCES `sharehouse`.`user` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 41
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`baseaddress`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`baseaddress` (
  `code` VARCHAR(30) NOT NULL,
  `sido` VARCHAR(30) NOT NULL,
  `gugun` VARCHAR(30) NOT NULL,
  `dong` VARCHAR(30) NOT NULL,
  `lat` VARCHAR(30) NOT NULL,
  `lng` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`code`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`houseinfo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`houseinfo` (
  `infono` INT NOT NULL AUTO_INCREMENT,
  `dong` VARCHAR(30) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `year` VARCHAR(30) NOT NULL,
  `jibun` VARCHAR(30) NOT NULL,
  `img` VARCHAR(1000) NULL DEFAULT NULL,
  `code` VARCHAR(30) NULL DEFAULT NULL,
  PRIMARY KEY (`infono`),
  INDEX `houseinfo_ibfk_1` (`code` ASC) VISIBLE,
  CONSTRAINT `houseinfo_ibfk_1`
    FOREIGN KEY (`code`)
    REFERENCES `sharehouse`.`baseaddress` (`code`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 4295
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`houserent`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`houserent` (
  `rentno` INT NOT NULL AUTO_INCREMENT,
  `dealdate` DATE NOT NULL,
  `area` DOUBLE NOT NULL,
  `floor` INT NOT NULL,
  `deposit` INT NOT NULL,
  `monthly` INT NOT NULL,
  `infono` INT NOT NULL,
  PRIMARY KEY (`rentno`),
  INDEX `infono_idx` (`infono` ASC) VISIBLE,
  CONSTRAINT `infono`
    FOREIGN KEY (`infono`)
    REFERENCES `sharehouse`.`houseinfo` (`infono`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 4295
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`chatroom`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`chatroom` (
  `roomid` INT NOT NULL AUTO_INCREMENT,
  `opendate` DATETIME NOT NULL,
  `rentno` INT NOT NULL,
  PRIMARY KEY (`roomid`),
  INDEX `rentno_idx` (`rentno` ASC) VISIBLE,
  CONSTRAINT `rent_no`
    FOREIGN KEY (`rentno`)
    REFERENCES `sharehouse`.`houserent` (`rentno`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 56
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`member`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`member` (
  `no` INT NOT NULL AUTO_INCREMENT,
  `roomid` INT NOT NULL,
  `id` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`no`),
  INDEX `room_id_chat_idx` (`roomid` ASC) VISIBLE,
  INDEX `user_id_chat_idx` (`id` ASC) VISIBLE,
  CONSTRAINT `room_id_chat`
    FOREIGN KEY (`roomid`)
    REFERENCES `sharehouse`.`chatroom` (`roomid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `user_id_chat`
    FOREIGN KEY (`id`)
    REFERENCES `sharehouse`.`user` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 35
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`message`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`message` (
  `msgno` INT NOT NULL AUTO_INCREMENT,
  `content` TEXT NOT NULL,
  `roomid` INT NOT NULL,
  `sender` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`msgno`),
  INDEX `room_id_msg_idx` (`roomid` ASC) VISIBLE,
  INDEX `user_id_msg_idx` (`sender` ASC) VISIBLE,
  CONSTRAINT `room_id_msg`
    FOREIGN KEY (`roomid`)
    REFERENCES `sharehouse`.`chatroom` (`roomid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `user_id_msg`
    FOREIGN KEY (`sender`)
    REFERENCES `sharehouse`.`user` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 157
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`search`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`search` (
  `searchno` INT NOT NULL AUTO_INCREMENT,
  `keyword` VARCHAR(100) NOT NULL,
  `searchdate` DATETIME NOT NULL,
  `userid` VARCHAR(50) NULL DEFAULT NULL,
  PRIMARY KEY (`searchno`),
  INDEX `id_idx` (`userid` ASC) VISIBLE,
  CONSTRAINT `userid`
    FOREIGN KEY (`userid`)
    REFERENCES `sharehouse`.`user` (`id`)
    ON DELETE SET NULL
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `sharehouse`.`wish`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sharehouse`.`wish` (
  `rentno` INT NOT NULL,
  `id` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`rentno`, `id`),
  INDEX `id_idx` (`id` ASC) VISIBLE,
  CONSTRAINT `id`
    FOREIGN KEY (`id`)
    REFERENCES `sharehouse`.`user` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `rentno`
    FOREIGN KEY (`rentno`)
    REFERENCES `sharehouse`.`houserent` (`rentno`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
